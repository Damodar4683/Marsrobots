﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsRobots
{
    public class ExceptionHelper
    {
       public static void LogExeption(Exception ex)
        {
           
            try
            {
                var appLog = new EventLog("MarsRobots");
                appLog.Source = "MarsRobots";
                appLog.WriteEntry(ex.Message +"\n"+ex.InnerException +"\n" + ex.StackTrace+"\n");
            }
            catch 
            {
                throw ex;
            }
        }
    }
}
